using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Estoque.DAO.Ancestral
{
    public abstract class DAOGenerico<T> where T : class
    {
//crud
    public void Create(T classe)
    {
        this.contexto.Set<T>.Add(instancia);
        this.contexto.SaveChanges();
    }

    public T Read(int id)
    {
        return this.contexto.Set<T>().Find(id);
    }

    public List<T> ReadAll()
    {
        
        return this.contexto.Set<T>().ToList();
    }

    public void Update(T classe)
    {
        this.contexto.Entry<T>(instancia).State = Entity.Modified;
        this.contexto.SaveChanges();
    }

    public void Delete(int id)
    {
        this.contexto.Set<T>().Remove(instancia);
        this.contexto.SaveChanges();
    }


    }

    }
