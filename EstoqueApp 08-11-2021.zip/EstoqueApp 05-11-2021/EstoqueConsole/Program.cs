﻿using System;
using System.Collections.Generic;
using System.Linq;
using ConsoleApp;
using EstoqueApp.ORM.Database;
using Microsoft.EntityFrameworkCore.SqlServer;


namespace EstoqueConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            EstoqueLambda estoque = new EstoqueLambda();
            estoque.TestarExibicao();
            

        }
    }
}
