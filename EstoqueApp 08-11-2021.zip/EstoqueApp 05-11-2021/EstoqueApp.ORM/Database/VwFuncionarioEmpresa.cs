﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class VwFuncionarioEmpresa
    {
        public long Chave { get; set; }
        public int FuncionarioId { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public DateTime DataAdmissao { get; set; }
        public string Ctps { get; set; }
        public long NumeroCtps { get; set; }
        public int SerieCtps { get; set; }
    }
}
