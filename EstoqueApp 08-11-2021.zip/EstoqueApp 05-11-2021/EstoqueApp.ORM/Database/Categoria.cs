﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class Categoria
    {
        public Categoria()
        {
            SubCategorias = new HashSet<SubCategoria>();
        }

        public int CategoriaId { get; set; }
        public string Descricao { get; set; }
        public DateTime? Inclusao { get; set; }

        public virtual ICollection<SubCategoria> SubCategorias { get; set; }
    }
}
