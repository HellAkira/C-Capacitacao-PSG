﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class FuncionarioPorDepartamentoRawDatum
    {
        public long FuncionarioId { get; set; }
        public int DepartamentoId { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
    }
}
