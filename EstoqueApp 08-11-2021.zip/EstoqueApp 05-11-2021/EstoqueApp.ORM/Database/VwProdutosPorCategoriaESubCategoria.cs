﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class VwProdutosPorCategoriaESubCategoria
    {
        public int CategoriaId { get; set; }
        public string CategoriaDescricao { get; set; }
        public int SubcategoriaId { get; set; }
        public string SubCategoriaDescricao { get; set; }
        public int ProdutoId { get; set; }
        public string ProdutoDescricao { get; set; }
    }
}
