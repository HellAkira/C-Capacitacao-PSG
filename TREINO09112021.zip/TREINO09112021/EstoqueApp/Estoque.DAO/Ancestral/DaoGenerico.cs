using System;
using System.Collections.Generic;
using System.Linq;
using Estoque.orm.Database;
using Microsoft.EntityFrameworkCore;




namespace Estoque.DAO.Ancestral
{
    public abstract class DaoGenerico<T> 
        where T : class
    {

        private CapacitacaoPSG2021H3Context contexto;

        public DaoGenerico(CapacitacaoPSG2021H3Context contexto)
        {
            this.contexto = contexto;
        }

        public T Create(T instancia)
        {
            this.contexto.Set<T>().Add(instancia);
            this.contexto.SaveChanges();
            return instancia;
        }

        public T Read(int id)
        {
            return this.contexto.Set<T>().Find(id);
        }

        public IEnumerable<T> ReadAll()
        {
            return this.contexto.Set<T>().ToList();
        }

    public T Update(T instancia)
    {
        this.contexto.Entry<T>(instancia).State = EntityState.Modified;
        this.contexto.SaveChanges();
        return instancia;
    }

    public void Delete(T instancia)
    {
        this.contexto.Set<T>().Remove(instancia);
    }

    }
}
