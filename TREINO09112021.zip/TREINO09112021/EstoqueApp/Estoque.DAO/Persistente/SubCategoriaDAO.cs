using System;
using Estoque.DAO.Ancestral;
using System.Collections.Generic;
using System.Linq;
using Estoque.orm.Database;
using Microsoft.EntityFrameworkCore;

namespace Estoque.DAO.Persistente
{
    public class SubCategoriaDAO : DaoGenerico<SubCategoria>
    {
        public SubCategoriaDAO(CapacitacaoPSG2021H3Context contexto) : base(contexto)
        {}
        
    }
}
