﻿using System;

namespace Estoque.DAO
{
    public class Class1
    {
    }
}
