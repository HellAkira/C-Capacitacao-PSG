﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class RawDataDepartamento
    {
        public int DeptoId { get; set; }
        public string Nome { get; set; }
    }
}
