﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class RawDataFuncionariosDadosEmpresa
    {
        public long Chave { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public DateTime DataAdmissao { get; set; }
        public string Ctps { get; set; }
        public long Ctpsnum { get; set; }
        public int Ctpsserie { get; set; }
    }
}
