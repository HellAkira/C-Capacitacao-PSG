﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Categoria
    {
        public Categoria()
        {
            SubCategoria = new HashSet<SubCategoria>();
        }

        public int CategoriaId { get; set; }
        public string Descricao { get; set; }
        public DateTime? Inclusao { get; set; }

        public virtual ICollection<SubCategoria> SubCategoria { get; set; }
    }
}
