﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Municipio
    {
        public int MunicipioId { get; set; }
        public string Descricao { get; set; }
        public int Ibge { get; set; }
        public int Ibge7 { get; set; }
        public int Ufid { get; set; }
        public string Siglauf { get; set; }
        public int? MesoregiaoId { get; set; }
        public int? MicroregiaoId { get; set; }
        public string Regiao { get; set; }
        public int Populacao2010 { get; set; }
        public string Porte { get; set; }
        public bool Capital { get; set; }
        public DateTime? DataInsert { get; set; }
    }
}
