﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Mesoregiao
    {
        public Mesoregiao()
        {
            Microregiaos = new HashSet<Microregiao>();
        }

        public int MesoregiaoId { get; set; }
        public string Descricao { get; set; }
        public int Ufid { get; set; }
        public DateTime? DataInsert { get; set; }

        public virtual UnidadesFederacao Uf { get; set; }
        public virtual ICollection<Microregiao> Microregiaos { get; set; }
    }
}
