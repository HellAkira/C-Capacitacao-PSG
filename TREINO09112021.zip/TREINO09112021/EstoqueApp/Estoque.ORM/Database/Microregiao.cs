﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Microregiao
    {
        public int MicroregiaoId { get; set; }
        public string Descricao { get; set; }
        public int MesoregiaoId { get; set; }
        public DateTime? DataInsert { get; set; }

        public virtual Mesoregiao Mesoregiao { get; set; }
    }
}
