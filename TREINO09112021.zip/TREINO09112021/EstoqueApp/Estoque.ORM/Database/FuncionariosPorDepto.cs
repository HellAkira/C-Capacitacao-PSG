﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class FuncionariosPorDepto
    {
        public int Funcid { get; set; }
        public int Deptoid { get; set; }
        public DateTime Datainicial { get; set; }
        public DateTime Datafinal { get; set; }
    }
}
