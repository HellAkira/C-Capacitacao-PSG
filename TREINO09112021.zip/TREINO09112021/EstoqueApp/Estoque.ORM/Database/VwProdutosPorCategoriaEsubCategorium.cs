﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class VwProdutosPorCategoriaEsubCategorium
    {
        public int CategoriaId { get; set; }
        public string CategoriaDescricao { get; set; }
        public int SubCategoriaId { get; set; }
        public string SubCategoriaDescricao { get; set; }
        public int ProdutoId { get; set; }
        public string ProdutoDescricao { get; set; }
    }
}
