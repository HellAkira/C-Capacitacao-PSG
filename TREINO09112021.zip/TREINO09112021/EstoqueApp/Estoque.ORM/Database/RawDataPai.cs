﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class RawDataPai
    {
        public int PaisId { get; set; }
        public string Nome { get; set; }
        public string Abreviacao { get; set; }
    }
}
