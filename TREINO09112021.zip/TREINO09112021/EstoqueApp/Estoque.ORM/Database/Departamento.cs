﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Departamento
    {
        public int DeptoId { get; set; }
        public string Nome { get; set; }
        public DateTime? Inclusao { get; set; }
    }
}
