﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Regiao
    {
        public Regiao()
        {
            UnidadesFederacaos = new HashSet<UnidadesFederacao>();
        }

        public int RegiaoId { get; set; }
        public string Descricao { get; set; }
        public string SiglaRegiao { get; set; }
        public DateTime? DataInsert { get; set; }

        public virtual ICollection<UnidadesFederacao> UnidadesFederacaos { get; set; }
    }
}
