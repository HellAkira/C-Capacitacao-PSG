﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class Funcionario
    {
        public Funcionario()
        {
            DepartamentosPorFuncionarios = new HashSet<DepartamentosPorFuncionario>();
        }

        public long Chave { get; set; }
        public int FuncionarioId { get; set; }
        public string Nome { get; set; }
        public string SobreNome { get; set; }
        public string Sexo { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Email { get; set; }
        public int PaisId { get; set; }
        public DateTime DataAdmissao { get; set; }
        public string Ctps { get; set; }
        public long Ctpsnum { get; set; }
        public int Ctpsserie { get; set; }
        public DateTime? Inclusao { get; set; }

        public virtual ICollection<DepartamentosPorFuncionario> DepartamentosPorFuncionarios { get; set; }
    }
}
