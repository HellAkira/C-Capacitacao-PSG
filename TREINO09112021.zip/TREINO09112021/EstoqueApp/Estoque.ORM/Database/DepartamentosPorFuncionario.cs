﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class DepartamentosPorFuncionario
    {
        public int DeptoPorFuncId { get; set; }
        public int FuncionarioId { get; set; }
        public int DeptoId { get; set; }
        public DateTime? DataInicial { get; set; }
        public DateTime? DataFinal { get; set; }

        public virtual Funcionario Funcionario { get; set; }
    }
}
