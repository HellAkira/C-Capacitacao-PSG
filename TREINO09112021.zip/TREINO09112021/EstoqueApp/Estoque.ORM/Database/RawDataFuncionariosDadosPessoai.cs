﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class RawDataFuncionariosDadosPessoai
    {
        public int FuncionarioId { get; set; }
        public long Chave { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public string Sexo { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Email { get; set; }
        public int PaisId { get; set; }
    }
}
