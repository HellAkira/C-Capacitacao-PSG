﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class UnidadesFederacao
    {
        public UnidadesFederacao()
        {
            Mesoregiaos = new HashSet<Mesoregiao>();
        }

        public int Ufid { get; set; }
        public string Descricao { get; set; }
        public string SiglaUf { get; set; }
        public int RegiaoId { get; set; }
        public DateTime? DataInsert { get; set; }

        public virtual Regiao Regiao { get; set; }
        public virtual ICollection<Mesoregiao> Mesoregiaos { get; set; }
    }
}
