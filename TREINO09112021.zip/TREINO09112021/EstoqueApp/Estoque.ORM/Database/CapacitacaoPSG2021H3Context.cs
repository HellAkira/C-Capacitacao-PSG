﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Estoque.orm.Database
{
    public partial class CapacitacaoPSG2021H3Context : DbContext
    {
        public CapacitacaoPSG2021H3Context()
        {
        }

        public CapacitacaoPSG2021H3Context(DbContextOptions<CapacitacaoPSG2021H3Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Categoria> Categoria { get; set; }
        public virtual DbSet<Departamento> Departamentos { get; set; }
        public virtual DbSet<DepartamentosPorFuncionario> DepartamentosPorFuncionarios { get; set; }
        public virtual DbSet<Funcionario> Funcionarios { get; set; }
        public virtual DbSet<FuncionariosPorDepto> FuncionariosPorDeptos { get; set; }
        public virtual DbSet<Mesoregiao> Mesoregioes { get; set; }
        public virtual DbSet<Microregiao> Microregioes { get; set; }
        public virtual DbSet<Municipio> Municipios { get; set; }
        public virtual DbSet<Produto> Produtos { get; set; }
        public virtual DbSet<RawDataDepartamento> RawDataDepartamentos { get; set; }
        public virtual DbSet<RawDataFuncionariosDadosEmpresa> RawDataFuncionariosDadosEmpresas { get; set; }
        public virtual DbSet<RawDataFuncionariosDadosPessoai> RawDataFuncionariosDadosPessoais { get; set; }
        public virtual DbSet<RawDataPai> RawDataPais { get; set; }
        public virtual DbSet<Regiao> Regioes { get; set; }
        public virtual DbSet<SubCategoria> SubCategoria { get; set; }
        public virtual DbSet<UnidadesFederacao> UnidadesFederacaos { get; set; }
        public virtual DbSet<VwFuncionarioPessoai> VwFuncionarioPessoais { get; set; }
        public virtual DbSet<VwProdutosPorCategoriaEsubCategorium> VwProdutosPorCategoriaEsubCategoria { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=(local);Initial Catalog=CapacitacaoPSG2021H3;User=sa;Password=senha123");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Categoria>(entity =>
            {
                entity.HasKey(e => e.CategoriaId);

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<Departamento>(entity =>
            {
                entity.HasKey(e => e.DeptoId);

                entity.ToTable("Departamento");

                entity.Property(e => e.DeptoId).HasColumnName("DeptoID");

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DepartamentosPorFuncionario>(entity =>
            {
                entity.HasKey(e => e.DeptoPorFuncId)
                    .HasName("PK_DeptoPorFuncID");

                entity.Property(e => e.DeptoPorFuncId).HasColumnName("DeptoPorFuncID");

                entity.Property(e => e.DataFinal).HasColumnType("datetime");

                entity.Property(e => e.DataInicial).HasColumnType("datetime");

                entity.Property(e => e.DeptoId).HasColumnName("DeptoID");

                entity.Property(e => e.FuncionarioId).HasColumnName("FuncionarioID");

                entity.HasOne(d => d.Funcionario)
                    .WithMany(p => p.DepartamentosPorFuncionarios)
                    .HasForeignKey(d => d.FuncionarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DepartamentosPorFuncionario_Departamento");
            });

            modelBuilder.Entity<Funcionario>(entity =>
            {
                entity.ToTable("Funcionario");

                entity.Property(e => e.FuncionarioId)
                    .ValueGeneratedNever()
                    .HasColumnName("FuncionarioID");

                entity.Property(e => e.Ctps)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("CTPS");

                entity.Property(e => e.Ctpsnum).HasColumnName("CTPSNum");

                entity.Property(e => e.Ctpsserie).HasColumnName("CTPSSerie");

                entity.Property(e => e.DataAdmissao).HasColumnType("datetime");

                entity.Property(e => e.DataNascimento).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao).HasColumnType("datetime");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.PaisId).HasColumnName("PaisID");

                entity.Property(e => e.Sexo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.SobreNome)
                    .IsRequired()
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FuncionariosPorDepto>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Datafinal)
                    .HasColumnType("datetime")
                    .HasColumnName("datafinal");

                entity.Property(e => e.Datainicial)
                    .HasColumnType("datetime")
                    .HasColumnName("datainicial");

                entity.Property(e => e.Deptoid).HasColumnName("deptoid");

                entity.Property(e => e.Funcid).HasColumnName("funcid");
            });

            modelBuilder.Entity<Mesoregiao>(entity =>
            {
                entity.ToTable("Mesoregiao");

                entity.Property(e => e.MesoregiaoId).HasColumnName("MesoregiaoID");

                entity.Property(e => e.DataInsert)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Ufid).HasColumnName("UFID");

                entity.HasOne(d => d.Uf)
                    .WithMany(p => p.Mesoregiaos)
                    .HasForeignKey(d => d.Ufid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Mesoregiao_UnidadesFederacao");
            });

            modelBuilder.Entity<Microregiao>(entity =>
            {
                entity.ToTable("Microregiao");

                entity.Property(e => e.MicroregiaoId).HasColumnName("MicroregiaoID");

                entity.Property(e => e.DataInsert)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MesoregiaoId).HasColumnName("MesoregiaoID");

                entity.HasOne(d => d.Mesoregiao)
                    .WithMany(p => p.Microregiaos)
                    .HasForeignKey(d => d.MesoregiaoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Microregiao_Mesoregiao");
            });

            modelBuilder.Entity<Municipio>(entity =>
            {
                entity.ToTable("Municipio");

                entity.Property(e => e.MunicipioId).HasColumnName("MunicipioID");

                entity.Property(e => e.DataInsert)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Ibge).HasColumnName("IBGE");

                entity.Property(e => e.Ibge7).HasColumnName("IBGE7");

                entity.Property(e => e.MesoregiaoId).HasColumnName("MesoregiaoID");

                entity.Property(e => e.MicroregiaoId).HasColumnName("MicroregiaoID");

                entity.Property(e => e.Porte)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Regiao).IsUnicode(false);

                entity.Property(e => e.Siglauf)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SIGLAUF")
                    .IsFixedLength(true);

                entity.Property(e => e.Ufid).HasColumnName("UFID");
            });

            modelBuilder.Entity<Produto>(entity =>
            {
                entity.ToTable("Produto");

                entity.Property(e => e.ProdutoId).HasColumnName("ProdutoID");

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SubCategoriaId).HasColumnName("SubCategoriaID");

                entity.HasOne(d => d.SubCategoria)
                    .WithMany(p => p.Produtos)
                    .HasForeignKey(d => d.SubCategoriaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Produto_SubCategoria");
            });

            modelBuilder.Entity<RawDataDepartamento>(entity =>
            {
                entity.HasKey(e => e.DeptoId);

                entity.ToTable("RAW DATA - Departamentos");

                entity.Property(e => e.DeptoId)
                    .ValueGeneratedNever()
                    .HasColumnName("DeptoID");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RawDataFuncionariosDadosEmpresa>(entity =>
            {
                entity.HasKey(e => e.Chave);

                entity.ToTable("RAW DATA - Funcionarios - Dados Empresa");

                entity.Property(e => e.Chave).ValueGeneratedNever();

                entity.Property(e => e.Ctps)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("CTPS");

                entity.Property(e => e.Ctpsnum).HasColumnName("CTPSNum");

                entity.Property(e => e.Ctpsserie).HasColumnName("CTPSSerie");

                entity.Property(e => e.DataAdmissao).HasColumnType("datetime");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<RawDataFuncionariosDadosPessoai>(entity =>
            {
                entity.HasKey(e => e.FuncionarioId);

                entity.ToTable("RAW DATA - Funcionarios - Dados Pessoais");

                entity.Property(e => e.FuncionarioId)
                    .ValueGeneratedNever()
                    .HasColumnName("FuncionarioID");

                entity.Property(e => e.DataNascimento).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.PaisId).HasColumnName("PaisID");

                entity.Property(e => e.Sexo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<RawDataPai>(entity =>
            {
                entity.HasKey(e => e.PaisId);

                entity.ToTable("RAW DATA - Pais");

                entity.Property(e => e.PaisId)
                    .ValueGeneratedNever()
                    .HasColumnName("PaisID");

                entity.Property(e => e.Abreviacao)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Regiao>(entity =>
            {
                entity.ToTable("Regiao");

                entity.Property(e => e.RegiaoId).HasColumnName("RegiaoID");

                entity.Property(e => e.DataInsert)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.SiglaRegiao)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<SubCategoria>(entity =>
            {
                entity.HasKey(e => e.SubCategoriaId);

                entity.Property(e => e.SubCategoriaId).HasColumnName("SubCategoriaID");

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Categoria)
                    .WithMany(p => p.SubCategoria)
                    .HasForeignKey(d => d.CategoriaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubCategoria_Categoria");
            });

            modelBuilder.Entity<UnidadesFederacao>(entity =>
            {
                entity.HasKey(e => e.Ufid);

                entity.ToTable("UnidadesFederacao");

                entity.Property(e => e.Ufid).HasColumnName("UFID");

                entity.Property(e => e.DataInsert)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RegiaoId).HasColumnName("RegiaoID");

                entity.Property(e => e.SiglaUf)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SiglaUF")
                    .IsFixedLength(true);

                entity.HasOne(d => d.Regiao)
                    .WithMany(p => p.UnidadesFederacaos)
                    .HasForeignKey(d => d.RegiaoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UnidadesFederacao_Regiao");
            });

            modelBuilder.Entity<VwFuncionarioPessoai>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VW_FuncionarioPessoais");

                entity.Property(e => e.DataNascimento).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FuncionarioId).HasColumnName("FuncionarioID");

                entity.Property(e => e.NomeFuncionario)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NomePais)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.PaisId).HasColumnName("PaisID");

                entity.Property(e => e.Sexo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwProdutosPorCategoriaEsubCategorium>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VW_ProdutosPorCategoriaESubCategoria");

                entity.Property(e => e.CategoriaDescricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.ProdutoDescricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.ProdutoId).HasColumnName("ProdutoID");

                entity.Property(e => e.SubCategoriaDescricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.SubCategoriaId).HasColumnName("SubCategoriaID");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
