﻿using System;
using System.Collections.Generic;
using Estoque.orm.Database;
using System.Linq;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace EstoqueConsole
{
    class Program
    {
        static void Main(string[] args)
        {
           CapacitacaoPSG2021H3Context contexto = new CapacitacaoPSG2021H3Context();
           List<Categoria> categorias = contexto.Categoria.ToList();
           foreach (Categoria item in categorias)
           {
               Console.WriteLine("ID ({0}) - {1} - {2}:", item.CategoriaId, item.Descricao, item.Inclusao);
           }
        }
    }
}
