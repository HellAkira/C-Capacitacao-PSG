using System;
using Estoque.orm.Database;
using Estoque.Poco.Model;
using AutoMapper;

namespace Estoque.Map
{
    public class ProdutoMap : AncestralMap
    {
        public ProdutoMap()
        {
            var configuration = new MapperConfiguration(
                cfg =>
                {
                    cfg.CreateMap<Produto, ProdutoPoco>();
                    cfg.CreateMap<ProdutoPoco, Produto>();
                }
            );
            this.getMapper = configuration.CreateMapper();
        }
    }
}
