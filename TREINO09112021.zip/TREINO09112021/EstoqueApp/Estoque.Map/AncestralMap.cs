using AutoMapper;
using System;

namespace Estoque.Map
{
    public abstract class AncestralMap
    {
        protected IMapper getMapper;

        public IMapper GetMapper
        {
            get => this.getMapper;
            set => this.getMapper = value;
        }
    }
}