﻿using System;

namespace Estoque.Map
{
    public class Class1
    {
    }
}
