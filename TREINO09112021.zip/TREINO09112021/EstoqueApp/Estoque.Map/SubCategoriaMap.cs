using System;
using Estoque.orm.Database;
using Estoque.Poco.Model;
using AutoMapper;

namespace Estoque.Map
{
    public class SubCategoriaMap : AncestralMap
    {
        public SubCategoriaMap()
        {
            var configuration = new MapperConfiguration(
                cfg =>
                {
                    cfg.CreateMap<SubCategoria, SubCategoriaPoco>();
                    cfg.CreateMap<SubCategoriaPoco, SubCategoria>();
                }
            );
            this.getMapper = configuration.CreateMapper();
        }
    }
}
