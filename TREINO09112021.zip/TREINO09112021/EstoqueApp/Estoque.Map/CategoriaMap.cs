using System;
using Estoque.orm.Database;
using Estoque.Poco.Model;
using AutoMapper;

namespace Estoque.Map
{
    public class CategoriaMap : AncestralMap
    {
        public CategoriaMap()
        {
            var configuration = new MapperConfiguration(
                cfg =>
                {
                    cfg.CreateMap<Categoria, CategoriaPoco>();
                    cfg.CreateMap<CategoriaPoco, Categoria>();
                }
            );
            this.getMapper = configuration.CreateMapper();
        }
    /*
              public class ContatoCoreMap : AncestralMap
    {
        public ContatoCoreMap()
        {
            var configuration = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ContatoCore, ContatoCorePoco>();
                cfg.CreateMap<ContatoCorePoco, ContatoCore>();
            });
            this.getMapper = configuration.CreateMapper();
        }
    }
    */
    }
}
