using System;


namespace Estoque.Poco.Model
{
    public class CategoriaPoco
    {
        public int CategoriaId { get; set; }
        public string Descricao { get; set; }
        public DateTime? Inclusao { get; set; }
    }
}
