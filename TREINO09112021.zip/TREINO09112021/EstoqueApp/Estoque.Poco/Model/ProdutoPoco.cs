using System;


namespace Estoque.Poco.Model
{
    public class ProdutoPoco
    {
        public int ProdutoId { get; set; }
        public int SubCategoriaId { get; set; }
        public int CategoriaId { get; set; }
        public string Descricao { get; set; }
        public DateTime? Inclusao { get; set; }
    }
}
