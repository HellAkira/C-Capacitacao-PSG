using Estoque.Map;
using System;
using AutoMapper;
using Estoque.orm.Database;

namespace Estoque.Services
{
    public class AncestralServices
    {
        protected CapacitacaoPSG2021H3Context contexto;
        protected AncestralMap mapa;
        public AncestralServices(CapacitacaoPSG2021H3Context contexto)
        {
            this.contexto = contexto;
        }
    }
}
