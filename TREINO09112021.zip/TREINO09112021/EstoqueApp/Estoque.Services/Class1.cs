﻿using System;

namespace Estoque.Services
{
    public class Class1
    {
    }
}
