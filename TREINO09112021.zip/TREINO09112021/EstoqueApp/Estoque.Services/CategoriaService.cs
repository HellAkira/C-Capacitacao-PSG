using System;
using Estoque.Map;
using AutoMapper;
using Estoque.orm.Database;
using Estoque.Poco.Model;
using System.Collections.Generic;
using System.Linq;
using Estoque.DAO.Persistente;

namespace Estoque.Services
{
    public class CategoriaService : AncestralServices
    {
        private CategoriaDAO dao;
        public CategoriaService(CapacitacaoPSG2021H3Context contexto) : base(contexto)
        { 
            this.mapa = new CategoriaMap();
            dao = new CategoriaDAO(contexto);
        }
        public List<CategoriaPoco> Browse()
        {
            List<Categoria> lista = this.dao.ReadAll().ToList();
            List<CategoriaPoco> listaPoco = this.mapa.GetMapper.Map<List<CategoriaPoco>>(lista);
            return listaPoco;
        }
        public CategoriaPoco Read()
        {
            Categoria cat = this.dao.Read(id);
            CategoriaPoco poc = this.mapa.GetMapper.Map<CategoriaPoco>(cat);
            return poc;
        }
        public CategoriaPoco Edit(CategoriaPoco poco)
        {
            Categoria cat = this.dao.Read(poco.CategoriaId);
            cat.Descricao = poco.Descricao;
            Categoria alterado = this.dao.Update(cat);
            CategoriaPoco alteradoPoco = this.mapa.GetMapper.Map<CategoriaPoco>(alterado);
            return alteradoPoco;
        }

        public CategoriaPoco Add(CategoriaPoco poco)
        {
            Categoria cat = this.GetMapper.Map<Categoria>(poco);
            Categoria novo = this.dao.Create(cat);
            CategoriaPoco novoPoco = this.mapa.GetMapper.Map<CategoriaPoco>(novo);
            return novoPoco;
        }
        public void Delete(int id)
        {
            Categoria cat = this.dao.Read(id);
            this.dao.Delete(cat);
        }

    
    }
}