﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class Departamento
    {
        public Departamento()
        {
            DepartamentoPorFuncionarios = new HashSet<DepartamentoPorFuncionario>();
        }

        public int DepartamentoId { get; set; }
        public string Descricao { get; set; }
        public DateTime Inclusao { get; set; }

        public virtual ICollection<DepartamentoPorFuncionario> DepartamentoPorFuncionarios { get; set; }
    }
}
