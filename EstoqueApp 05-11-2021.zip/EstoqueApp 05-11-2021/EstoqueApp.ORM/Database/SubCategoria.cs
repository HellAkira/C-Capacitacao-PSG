﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class SubCategoria
    {
        public SubCategoria()
        {
            Produtos = new HashSet<Produto>();
        }

        public int SubCategoriaId { get; set; }
        public int CategoriaId { get; set; }
        public string Descricao { get; set; }
        public DateTime? Inclusao { get; set; }

        public virtual Categoria Categorias { get; set; }
        public virtual ICollection<Produto> Produtos { get; set; }
    }
}
