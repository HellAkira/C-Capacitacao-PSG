﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class Funcionario
    {
        public Funcionario()
        {
            DepartamentoPorFuncionarios = new HashSet<DepartamentoPorFuncionario>();
        }

        public long Chave { get; set; }
        public int FuncionarioId { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public DateTime Admissao { get; set; }
        public string Sexo { get; set; }
        public DateTime Nascimento { get; set; }
        public string Email { get; set; }
        public string Ctps { get; set; }
        public long NumeroCtps { get; set; }
        public int SerieCtps { get; set; }
        public int PaisId { get; set; }
        public DateTime? Inclusao { get; set; }

        public virtual Pais Pais { get; set; }
        public virtual ICollection<DepartamentoPorFuncionario> DepartamentoPorFuncionarios { get; set; }
    }
}
