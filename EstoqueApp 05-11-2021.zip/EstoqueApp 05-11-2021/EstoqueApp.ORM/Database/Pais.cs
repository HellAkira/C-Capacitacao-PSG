﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class Pais
    {
        public Pais()
        {
            Funcionarios = new HashSet<Funcionario>();
        }

        public int PaisId { get; set; }
        public string Descricao { get; set; }
        public string Sigla { get; set; }
        public DateTime DataInsert { get; set; }

        public virtual ICollection<Funcionario> Funcionarios { get; set; }
    }
}
