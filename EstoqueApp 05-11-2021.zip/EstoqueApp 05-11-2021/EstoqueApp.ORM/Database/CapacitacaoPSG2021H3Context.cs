﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace EstoqueApp.ORM.Database
{
    public partial class CapacitacaoPSG2021H3Context : DbContext
    {
        public CapacitacaoPSG2021H3Context()
        {
        }

        public CapacitacaoPSG2021H3Context(DbContextOptions<CapacitacaoPSG2021H3Context> options)
            : base(options)
        {
        }


    
        public virtual DbSet<Categoria> Categorias { get; set; }
        public virtual DbSet<Departamento> Departamentos { get; set; }
        public virtual DbSet<DepartamentoPorFuncionario> DepartamentoPorFuncionarios { get; set; }
        public virtual DbSet<Funcionario> Funcionarios { get; set; }
        public virtual DbSet<FuncionarioPorDepartamentoRawDatum> FuncionarioPorDepartamentoRawData { get; set; }
        public virtual DbSet<Pais> Pais { get; set; }
        public virtual DbSet<Produto> Produtos { get; set; }
        public virtual DbSet<SubCategoria> SubCategorias { get; set; }
        public virtual DbSet<VwFuncionarioEmpresa> VwFuncionarioEmpresas { get; set; }
        public virtual DbSet<VwFuncionarioPessoa> VwFuncionarioPessoas { get; set; }
        public virtual DbSet<VwProdutosPorCategoriaESubCategoria> VwProdutosPorCategoriaEsubCategoria { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=(local);Initial Catalog=CapacitacaoPSG2021H3;User=teste;Password=senha123");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Categoria>(entity =>
            {
                entity.ToTable("Categoria");

                entity.HasKey(e => e.CategoriaId);

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<Departamento>(entity =>
            {
                entity.ToTable("Departamento");

                entity.Property(e => e.DepartamentoId).HasColumnName("DepartamentoID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<DepartamentoPorFuncionario>(entity =>
            {
                entity.ToTable("DepartamentoPorFuncionario");

                entity.Property(e => e.DepartamentoPorFuncionarioId).HasColumnName("DepartamentoPorFuncionarioID");

                entity.Property(e => e.DataFim).HasColumnType("datetime");

                entity.Property(e => e.DataInicio).HasColumnType("datetime");

                entity.Property(e => e.DepartamentoId).HasColumnName("DepartamentoID");

                entity.Property(e => e.FuncionarioId).HasColumnName("FuncionarioID");

                entity.HasOne(d => d.Departamento)
                    .WithMany(p => p.DepartamentoPorFuncionarios)
                    .HasForeignKey(d => d.DepartamentoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DepartamentoPorFuncionario_Departamento");

                entity.HasOne(d => d.Funcionario)
                    .WithMany(p => p.DepartamentoPorFuncionarios)
                    .HasForeignKey(d => d.FuncionarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DepartamentoPorFuncionario_Funcionario");
            });

            modelBuilder.Entity<Funcionario>(entity =>
            {
                entity.ToTable("Funcionario");

                entity.Property(e => e.FuncionarioId)
                    .ValueGeneratedNever()
                    .HasColumnName("FuncionarioID");

                entity.Property(e => e.Admissao).HasColumnType("datetime");

                entity.Property(e => e.Ctps)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("CTPS");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Nascimento).HasColumnType("datetime");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumeroCtps).HasColumnName("NumeroCTPS");

                entity.Property(e => e.PaisId).HasColumnName("PaisID");

                entity.Property(e => e.SerieCtps).HasColumnName("SerieCTPS");

                entity.Property(e => e.Sexo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Pais)
                    .WithMany(p => p.Funcionarios)
                    .HasForeignKey(d => d.PaisId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Funcionario_Pais");
            });

            modelBuilder.Entity<FuncionarioPorDepartamentoRawDatum>(entity =>
            {   

                entity.HasNoKey();

                entity.Property(e => e.DataFim).HasColumnType("datetime");

                entity.Property(e => e.DataInicio).HasColumnType("datetime");

                entity.Property(e => e.DepartamentoId).HasColumnName("DepartamentoID");

                entity.Property(e => e.FuncionarioId).HasColumnName("FuncionarioID");
            });

            modelBuilder.Entity<Pais>(entity =>
            {   
                entity.ToTable("Pais");

                entity.HasKey(e => e.PaisId);

                entity.Property(e => e.PaisId).HasColumnName("PaisID");

                entity.Property(e => e.DataInsert)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sigla)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);
            });

            modelBuilder.Entity<Produto>(entity =>
            {
                entity.ToTable("Produto");

                entity.Property(e => e.ProdutoId).HasColumnName("ProdutoID");

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SubcategoriaId).HasColumnName("SubcategoriaID");

                entity.HasOne(d => d.Subcategoria)
                    .WithMany(p => p.Produtos)
                    .HasForeignKey(d => d.SubcategoriaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Produto_SubCategoria");
            });

            modelBuilder.Entity<SubCategoria>(entity =>
            {   
                entity.ToTable("SubCategoria"); 

                entity.HasKey(e => e.SubCategoriaId);

                entity.Property(e => e.SubCategoriaId).HasColumnName("SubCategoriaID");

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Inclusao)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Categorias)
                    .WithMany(p => p.SubCategorias)
                    .HasForeignKey(d => d.CategoriaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubCategoria_Categoria");
            });

            modelBuilder.Entity<VwFuncionarioEmpresa>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VW_FuncionarioEmpresa");

                entity.Property(e => e.Ctps)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("CTPS");

                entity.Property(e => e.DataAdmissao).HasColumnType("datetime");

                entity.Property(e => e.FuncionarioId).HasColumnName("FuncionarioID");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumeroCtps).HasColumnName("NumeroCTPS");

                entity.Property(e => e.SerieCtps).HasColumnName("SerieCTPS");

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFuncionarioPessoa>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VW_FuncionarioPessoa");

                entity.Property(e => e.DataNascimento).HasColumnType("datetime");

                entity.Property(e => e.Descricao)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FuncionarioId).HasColumnName("FuncionarioID");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaisId).HasColumnName("PaisID");

                entity.Property(e => e.Sexo)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Sobrenome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwProdutosPorCategoriaESubCategoria>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("VW_ProdutosPorCategoriaESubCategoria");

                entity.Property(e => e.CategoriaDescricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.CategoriaId).HasColumnName("CategoriaID");

                entity.Property(e => e.ProdutoDescricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.ProdutoId).HasColumnName("ProdutoID");

                entity.Property(e => e.SubCategoriaDescricao)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.SubcategoriaId).HasColumnName("SubcategoriaID");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
